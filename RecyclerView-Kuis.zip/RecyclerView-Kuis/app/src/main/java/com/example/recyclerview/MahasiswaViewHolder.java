package com.example.recyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import com.example.recyclerview.R;

public class MahasiswaViewHolder extends RecyclerView.ViewHolder {

    public TextView tvNama;
    public TextView tvNPM;
    public TextView tvNohp;

    public MahasiswaViewHolder(View itemView) {
        super(itemView);
        tvNama = itemView.findViewById(R.id.tv_nama_mahasiswa);
        tvNPM= itemView.findViewById(R.id.tv_npm_mahasiswa);
        tvNohp = itemView.findViewById(R.id.tv_nohp_mahasiswa);
    }

    public void bindToMahasiswa(Mahasiswa mahasiswa, View.OnClickListener onClickListener){
        tvNama.setText(mahasiswa.Nama);
        tvNPM.setText(mahasiswa.NPM);
        tvNohp.setText(mahasiswa.Nohp);
    }
}
