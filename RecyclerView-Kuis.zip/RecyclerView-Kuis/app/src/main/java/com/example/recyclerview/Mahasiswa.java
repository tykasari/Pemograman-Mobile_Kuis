package com.example.recyclerview;

import com.google.firebase.database.Exclude;

import java.util.HashMap;
import java.util.Map;



public class Mahasiswa {
    public String Nama;
    public String NPM;
    public String Nohp;

    public Mahasiswa() {
    }

    public Mahasiswa(String Nama, String NPM, String Nohp) {
        this.Nama = Nama;
        this.NPM = NPM;
        this.Nohp = Nohp;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("Nama", Nama);
        result.put("NPM", NPM);
        result.put("Nohp", Nohp);
        return result;
    }

}